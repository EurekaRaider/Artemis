# Artemis UI 原型评审快照 · 2026-09-05

解压后直接打开 ui-prototype/apple-inspired-ui.html；组件规范入口为 ui-prototype/components.html。请保留整个 ui-prototype 目录，无需安装依赖即可离线预览。脚本运行时需要现代 Chromium。

本包逐文件收录 feat/im-feishu 工作区的 docs/ui-prototype（包含未提交更新）；没有改写原型。SNAPSHOT-MANIFEST.json 记录原文件大小与 SHA-256。排除 .DS_Store、node_modules、.git、__pycache__ 等本机或依赖目录（若存在）。

原型是布局和交互规格，文件编辑、提交、IM、设备在线状态与身份等均为演示，不能视为真实后端能力。目标产品为 main 提交 bdded70d937b54aad615f0f87de57d5fb31271b8（1.4.62）。原型内的 1.4.40 等版本标签、70 卡历史文字与部分早期验证记录仍保留原样；本轮运行的组件目录断言为 73 卡。

review-evidence/ 保存本次重新运行的 12 项 library-check、34 项 workspace-check 结果，以及人工查看的工作台和 IM 设置截图。原型原有 contrast/ 报告属于历史证据，本次未重跑完整对比度矩阵。

重跑检查需要本地 Playwright 与 Chromium：

    node ui-prototype/tools/library-check.mjs
    node ui-prototype/tools/workspace-check.mjs

该检查不替代产品 React/Electron、真实 IM 平台或 Windows/macOS 安装包验收。主提案见同一 GitHub Discussion。
